package com.spring.sample;

public interface ColorService {
	
	public String applyColor();

}
