package com.spring.sample;

public interface Shape {
	public String drawShape();
	public String colorShape();
	
	
	

}
