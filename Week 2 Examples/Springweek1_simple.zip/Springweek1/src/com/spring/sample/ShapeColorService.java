package com.spring.sample;

public class ShapeColorService implements ColorService{
	
	public String applyColor() {
		return "Shape Colored";

}
}
